﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Storages
{
    internal class Storages
    {
        public int Id { get; set; }
        public string Storage_name { get; set; }
        public string Storekeeper_surname { get; set; }
        public List<Purchase> Purchase { get; set; } = new List<Purchase>(); 
        public List<Expence> Expence { get; set; } = new List<Expence>();
        public List<Stock_balance> Stock_balance { get; set; } = new List<Stock_balance>();
    }
}
