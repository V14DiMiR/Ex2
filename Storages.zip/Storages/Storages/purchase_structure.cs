﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Storages
{
    internal class purchase_structure
    {
        [Key]
        public int PurchaseId { get; set; }
        public int ProductsId { get; set; }
        public int quantity { get; set; }
        public string unloader_full_name { get; set; }
        public Products Products { get; set; } 
        public Purchase Purchase { get; set; }
    }
}
