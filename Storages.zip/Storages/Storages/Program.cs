﻿using System;
using Microsoft.EntityFrameworkCore;

namespace Storages
{
    class Program
    {
        static void Main(string[] args)
        {
            //Добавление данных
            using (AppContext context = new AppContext())
            {
                /* //Заполнение базы данных
                context.Storages.Add(new Storages() { Storage_name = "Metro", Storekeeper_surname = "Ivanov V.V." });
                context.Storages.Add(new Storages() { Storage_name = "Achan", Storekeeper_surname = "Petrov M.V." });
                context.Products.Add(new Products() { name_product = "Parlament Sivler", unit_of_measurement = "шт", price = 68, barcode = 48207782 });
                context.Products.Add(new Products() { name_product = "Сметана 15%", unit_of_measurement = "шт", price = 18, barcode = 482005266 });
                context.Stock_balance.Add(new Stock_balance() { StoragesId = 1, ProductsId = 1, quantity = 10, expiration_date = "2022-05-01", cell_id = 1 });
                context.Stock_balance.Add(new Stock_balance() { StoragesId = 2, ProductsId = 2, quantity = 30, expiration_date = "2022-08-20", cell_id = 1 });
                context.Expence.Add(new Expence() { Date="2021-11-11", StoragesId = 1, operator_full_name = "Ivanova M.M."});
                context.expence_structure.Add(new expence_structure() { ExpenceId = 1, ProductsId = 1, quantity = 3, unloader_full_name = "Ivanova M.M." }); ;
                context.Purchase.Add(new Purchase() { Date = "2021-11-11", StoragesId = 1, Provider = "ЧЧК", operator_full_name = "Ivanova M.M." });
                context.purchase_structure.Add(new purchase_structure() {PurchaseId = 1, ProductsId = 2, quantity = 10, unloader_full_name = "Ivanova M.M." });
                context.SaveChanges();*/
                /*//Изменение названия товара с Parlament Silver на Parlament Blue
                Products product1 = context.Products.FirstOrDefault(p => p.name_product == "Parlament Sivler");
                if (product1 != null)
                {
                    product1.name_product = "Parlament Blue";
                    context.SaveChanges();
                }*/
                // Удаление Сметаны 15%
                Products product2 = context.Products.FirstOrDefault(p => p.name_product == "Сметана 15%");
                if (product2 != null)
                {
                    context.Products.Remove(product2);
                    context.SaveChanges();
                }

                Console.WriteLine("All good)");
            }
        }
    }
}

