﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Storages
{
    
    internal class Stock_balance
    {
        [Key]
        public int StoragesId { get; set; }
        public int ProductsId { get; set; }
        public int quantity { get; set; }
        public string expiration_date { get; set; }
        public int cell_id { get; set; }
        public Storages Storages { get; set; } // склад
        public Products Products { get; set; } //товары
    }
}
