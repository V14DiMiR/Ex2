﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Storages.Migrations
{
    public partial class v1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Expence",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Date = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StoragesId = table.Column<int>(type: "int", nullable: false),
                    product = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    quantity = table.Column<int>(type: "int", nullable: false),
                    operator_full_name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Expence", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Expence_Storages_StoragesId",
                        column: x => x.StoragesId,
                        principalTable: "Storages",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name_product = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    unit_of_measurement = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    price = table.Column<int>(type: "int", nullable: false),
                    barcode = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Purchase",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Date = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StoragesId = table.Column<int>(type: "int", nullable: false),
                    Provider = table.Column<int>(type: "int", nullable: false),
                    product = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    quantity = table.Column<int>(type: "int", nullable: false),
                    operator_full_name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Purchase", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Purchase_Storages_StoragesId",
                        column: x => x.StoragesId,
                        principalTable: "Storages",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "expence_structure",
                columns: table => new
                {
                    ExpenceId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductsId = table.Column<int>(type: "int", nullable: false),
                    quantity = table.Column<int>(type: "int", nullable: false),
                    unloader_full_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ExpenceId1 = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_expence_structure", x => x.ExpenceId);
                    table.ForeignKey(
                        name: "FK_expence_structure_Expence_ExpenceId1",
                        column: x => x.ExpenceId1,
                        principalTable: "Expence",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_expence_structure_Products_ProductsId",
                        column: x => x.ProductsId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Stock_balance",
                columns: table => new
                {
                    StoragesId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductsId = table.Column<int>(type: "int", nullable: false),
                    quantity = table.Column<int>(type: "int", nullable: false),
                    expiration_date = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    cell_id = table.Column<int>(type: "int", nullable: false),
                    StoragesId1 = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Stock_balance", x => x.StoragesId);
                    table.ForeignKey(
                        name: "FK_Stock_balance_Products_ProductsId",
                        column: x => x.ProductsId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Stock_balance_Storages_StoragesId1",
                        column: x => x.StoragesId1,
                        principalTable: "Storages",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "purchase_structure",
                columns: table => new
                {
                    PurchaseId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductsId = table.Column<int>(type: "int", nullable: false),
                    quantity = table.Column<int>(type: "int", nullable: false),
                    unloader_full_name = table.Column<int>(type: "int", nullable: false),
                    PurchaseId1 = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_purchase_structure", x => x.PurchaseId);
                    table.ForeignKey(
                        name: "FK_purchase_structure_Products_ProductsId",
                        column: x => x.ProductsId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_purchase_structure_Purchase_PurchaseId1",
                        column: x => x.PurchaseId1,
                        principalTable: "Purchase",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Expence_StoragesId",
                table: "Expence",
                column: "StoragesId");

            migrationBuilder.CreateIndex(
                name: "IX_expence_structure_ExpenceId1",
                table: "expence_structure",
                column: "ExpenceId1");

            migrationBuilder.CreateIndex(
                name: "IX_expence_structure_ProductsId",
                table: "expence_structure",
                column: "ProductsId");

            migrationBuilder.CreateIndex(
                name: "IX_Purchase_StoragesId",
                table: "Purchase",
                column: "StoragesId");

            migrationBuilder.CreateIndex(
                name: "IX_purchase_structure_ProductsId",
                table: "purchase_structure",
                column: "ProductsId");

            migrationBuilder.CreateIndex(
                name: "IX_purchase_structure_PurchaseId1",
                table: "purchase_structure",
                column: "PurchaseId1");

            migrationBuilder.CreateIndex(
                name: "IX_Stock_balance_ProductsId",
                table: "Stock_balance",
                column: "ProductsId");

            migrationBuilder.CreateIndex(
                name: "IX_Stock_balance_StoragesId1",
                table: "Stock_balance",
                column: "StoragesId1");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "expence_structure");

            migrationBuilder.DropTable(
                name: "purchase_structure");

            migrationBuilder.DropTable(
                name: "Stock_balance");

            migrationBuilder.DropTable(
                name: "Expence");

            migrationBuilder.DropTable(
                name: "Purchase");

            migrationBuilder.DropTable(
                name: "Products");
        }
    }
}
