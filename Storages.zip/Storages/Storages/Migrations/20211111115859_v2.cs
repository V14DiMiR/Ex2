﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Storages.Migrations
{
    public partial class v2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "product",
                table: "Purchase");

            migrationBuilder.DropColumn(
                name: "quantity",
                table: "Purchase");

            migrationBuilder.DropColumn(
                name: "product",
                table: "Expence");

            migrationBuilder.DropColumn(
                name: "quantity",
                table: "Expence");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "product",
                table: "Purchase",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "quantity",
                table: "Purchase",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "product",
                table: "Expence",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "quantity",
                table: "Expence",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
