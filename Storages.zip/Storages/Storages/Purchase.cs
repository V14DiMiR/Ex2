﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Storages
{
    internal class Purchase
    {
        public int Id { get; set; }
        public string Date { get; set; }
        public int StoragesId { get; set; }
        public string Provider { get; set; }
        public string operator_full_name { get; set; }
        public Storages Storages { get; set; } // склад
        public List<purchase_structure> purchase_structure { get; set; } = new List<purchase_structure>(); 

    }
}
