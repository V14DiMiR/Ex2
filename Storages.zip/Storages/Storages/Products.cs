﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Storages
{
    internal class Products
    {
        public int Id { get; set; }
        public string name_product { get; set; }
        public string unit_of_measurement { get; set; }
        public int price { get; set; }
        public int barcode { get; set; }
        public List<Stock_balance> Stock_balance { get; set; } = new List<Stock_balance>();
        public List<expence_structure> expence_structure { get; set; } = new List<expence_structure>();
        public List<purchase_structure> purchase_structure { get; set; } = new List<purchase_structure>(); 


    }
}
