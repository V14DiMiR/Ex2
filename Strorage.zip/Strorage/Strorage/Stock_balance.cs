﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strorage
{
    internal class Stock_balance
    {
        public int Id { get; set; }
        public int StoragesId { get; set; }
        public int ProductsId { get; set; }
        public int quantity { get; set; }
        public string expiration_date { get; set; }
        public int cell_id { get; set; }
        public Storages Storages { get; set; } // склад
        public Products Products { get; set; } //товары
    }
}
