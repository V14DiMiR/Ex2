﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strorage
{
    internal class AppContext : DbContext

    {
        public DbSet<Storages> Storages { get; set; }
        public DbSet<Products> Products { get; set; }
        public DbSet<Stock_balance> Stock_balance { get; set; }
        public DbSet<Expence> Expence { get; set; }
        public DbSet<expence_structure> expence_structure { get; set; }
        public DbSet<Purchase> Purchase { get; set; }
        public DbSet<purchase_structure> purchase_structure { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb; Database=Storage; Trusted_Connection=True");
        }
    }
}
