﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strorage
{
    internal class expence_structure
    {
        public int Id { get; set; }
        public int ExpenceId { get; set; }
        public int ProductsId { get; set; }
        public int quantity { get; set; }
        public string unloader_full_name { get; set; }
        public Products Products { get; set; }
        public Expence Expence { get; set; }
    }
}
