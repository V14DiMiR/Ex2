﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;


namespace Strorage
{
    class Program
    {
        static void Main(string[] args)
        {
            using (AppContext context = new AppContext())
            { //Наполнение базы данных
              //context.Storages.Add(new Storages() { Storage_name = "Metro", Storekeeper_surname = "Ivanov V.V." });
              // context.Storages.Add(new Storages() { Storage_name = "Achan", Storekeeper_surname = "Petrov M.V." });
              //context.Products.Add(new Products() { name_product = "Parlament Sivler", unit_of_measurement = "шт", price = 68, barcode = 48207782 });
              // context.Products.Add(new Products() { name_product = "Намазка", unit_of_measurement = "шт", price = 25, barcode = 445789966 });
              //context.Stock_balance.Add(new Stock_balance() { StoragesId = 1, ProductsId = 1, quantity = 10, expiration_date = "2022-05-01", cell_id = 1 });
              // context.Stock_balance.Add(new Stock_balance() { StoragesId = 2, ProductsId = 2, quantity = 30, expiration_date = "2022-08-20", cell_id = 1 });
              // context.Expence.Add(new Expence() { Date = "2021-11-11", StoragesId = 1, operator_full_name = "Ivanova M.M." });
              // context.expence_structure.Add(new expence_structure() { ExpenceId = 1, ProductsId = 1, quantity = 3, unloader_full_name = "Ivanova M.M." }); ;
              // context.Purchase.Add(new Purchase() { Date = "2021-11-11", StoragesId = 1, Provider = "ЧЧК", operator_full_name = "Ivanova M.M." });
              // context.purchase_structure.Add(new purchase_structure() { PurchaseId = 1, ProductsId = 2, quantity = 10, unloader_full_name = "Ivanova M.M." });
              //  context.SaveChanges();
              //Фильтрация 1
                /*var products = (from Products in context.Products
                                where Products.Id == 1
                                select Products).ToList();
                foreach (var Products in products)
                    Console.WriteLine($"{Products.name_product} {Products.price}");*/
                //Фильтрация 2
                /*var balance = (from Stock_balance in context.Stock_balance.Include(p=>p.Storages)
                                where Stock_balance.StoragesId == 1
                                select Stock_balance).ToList();
                foreach (var Stock_balance in balance)
                    Console.WriteLine($"Айди товара {Stock_balance.ProductsId}, Кол-во {Stock_balance.quantity}");*/
                //First()/FirstOrDefault()
                /*Products Products = context.Products.FirstOrDefault(p=>p.price == 68);
                if (Products != null)
                    Console.WriteLine(Products.name_product);*/
                // Сортировка
                /*var balance = context.Stock_balance.OrderByDescending(p => p.quantity);
                foreach (var Stock_balance in balance)
                    Console.WriteLine($"Айди продукта {Stock_balance.ProductsId} Кол-во {Stock_balance.quantity} Годен до {Stock_balance.cell_id}");*/
                //Обьединение 
                /*var expence = from Expence in context.Expence
                              join Storages in context.Storages on Expence.StoragesId equals Storages.Id
                              select new
                              {
                                  Storage_name = Storages.Storage_name,
                                  Date = Expence.Date,
                                  Operator = Expence.operator_full_name
                              };
                foreach (var u in expence)
                    Console.WriteLine($"Склад {u.Storage_name} Дата расхода {u.Date} Оператор {u.Operator}");*/
                //Хранимая процедура
                /*var param = new Microsoft.Data.SqlClient.SqlParameter
                {
                    ParameterName = "@product",
                    SqlDbType = System.Data.SqlDbType.VarChar,
                    Direction = System.Data.ParameterDirection.Output,
                    Size = 50
                };
                context.Database.ExecuteSqlRaw("Procedure @product OUT", param);
                Console.WriteLine(param.Value);*/


            }
        }
    }
}

